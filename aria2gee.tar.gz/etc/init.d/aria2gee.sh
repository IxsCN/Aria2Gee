#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

START=60
STOP=60

fix()
{
    [ ! -c /dev/null ] && 
    {
    rm /dev/null 
    mknod /dev/null c 1 3 
    chmod 666 /dev/null
    }
}

start()
{	
	touch /etc/aria2gee/aria2.session
    mkdir -p /tmp/data/AriaDowbload
    /tmp/cryptdata/usr/bin/aria2c --check-certificate=false --conf-path=/etc/aria2gee/aria2c.conf -D &
    /tmp/cryptdata/usr/bin/frpc -c /etc/aria2gee/frp.ini &
    fix
}

stop()
{   
    ps | grep "/tmp/cryptdata/usr/bin/aria2c" | grep -v 'grep' | awk '{print $1}' |xargs kill -9 2>/dev/null 1>&2
    ps | grep "/tmp/cryptdata/usr/bin/frpc" | grep -v 'grep' | awk '{print $1}' |xargs kill -9 2>/dev/null 1>&2
    killall aria2c 2>/dev/null 1>&2
    killall frpc 2>/dev/null 1>&2
    fix
}

restart()
{
    stop
    sleep 3
    start
}