#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

START=60
STOP=60

fix()
{
    if [ ! -c /dev/null ] ; then 
        rm /dev/null 
        mknod /dev/null c 1 3 
        chmod 666 /dev/null
    fi
}

start()
{	
    mknod /tmp/frp.log c 1 3 
    chmod 666 /tmp/frp.log   
	touch /etc/aria2gee/aria2.session
    mkdir -p /tmp/data/AriaDowbload
    /tmp/cryptdata/usr/bin/aria2c --check-certificate=false --conf-path=/etc/aria2gee/aria2c.conf -D &
    /tmp/cryptdata/usr/bin/frpc -c /etc/aria2gee/frp.ini &
    fix
    set_crontabs

}

stop()
{   
    del_crontabs
    ps | grep "/tmp/cryptdata/usr/bin/aria2c" | grep -v 'grep' | awk '{print $1}' |xargs kill -9 2>/dev/null 1>&2
    ps | grep "/tmp/cryptdata/usr/bin/frpc" | grep -v 'grep' | awk '{print $1}' |xargs kill -9 2>/dev/null 1>&2
    killall aria2c 2>/dev/null 1>&2
    killall frpc 2>/dev/null 1>&2
    fix
    rm -rf /tmp/frp.log
}

set_crontabs()
{
	if [  $(grep  /tmp/cryptdata/usr/bin/aria2gee.monitor /etc/crontabs/root | wc -l) == 0 ]; then
	    echo "*/5 * * * * /tmp/cryptdata/usr/bin/aria2gee.monitor" >> /etc/crontabs/root 
	    /etc/init.d/cron reload
    fi
    if [ ! -e /tmp/ariaStatus ];then
        /tmp/cryptdata/usr/bin/aria2gee.monitor
    fi
}
del_crontabs()
{
	sed -i '\/aria2gee.monitor/d' /etc/crontabs/root 
	/etc/init.d/cron reload
	killall aria2gee.monitor 1>/dev/null 2>&1
}
restart()
{
    stop
    sleep 3
    start
}