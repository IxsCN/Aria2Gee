#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

START=60
STOP=60

fix()
{
    if [ ! -c /dev/null ] ; then 
        rm /dev/null 
        mknod /dev/null c 1 3 
        chmod 666 /dev/null
    fi
}

start()
{	
    rm -rf /tmp/frp.log
    mknod /tmp/frp.log c 1 3 
    chmod 666 /tmp/frp.log
	touch /etc/aria2gee/aria2.session
    mkdir -p /tmp/data/AriaDowbload
    /tmp/cryptdata/usr/bin/aria2c --check-certificate=false --conf-path=/etc/aria2gee/aria2c.conf -D &
    /tmp/cryptdata/usr/bin/frpc -c /etc/aria2gee/frp.ini > /dev/null&
    fix
    set_crontabs
}

stop()
{   
    del_crontabs
    ps | grep "/tmp/cryptdata/usr/bin/aria2c" | grep -v 'grep' | awk '{print $1}' |xargs kill -9 2>/dev/null 1>&2
    ps | grep "/tmp/cryptdata/usr/bin/frpc" | grep -v 'grep' | awk '{print $1}' |xargs kill -9 2>/dev/null 1>&2
    killall aria2c 2>/dev/null 1>&2
    killall frpc 2>/dev/null 1>&2
    fix

}

set_crontabs()
{
	if [  $(grep /tmp/cryptdata/usr/bin/aria2gee.cron  /etc/crontabs/root | wc -l) == 0 ]; then
	    echo "*/5 * * * * /tmp/cryptdata/usr/bin/aria2gee.cron" >> /etc/crontabs/root 
	    /etc/init.d/cron reload
    fi
}
del_crontabs()
{
    killall aria2gee.cron > /dev/null
	sed -i '/aria2gee.cron/d' /etc/crontabs/root 
	/etc/init.d/cron reload
    killall aria2gee.cron > /dev/null
}

restart()
{
    stop
    sleep 3
    start
}