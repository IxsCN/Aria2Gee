#!/bin/sh
. /etc/aria2gee/Aria2Gee.conf
#echo "finshed "$1" "$2" "$3> /tmp/hook
chmod 777 $path/*
chmod 777 $3